<?php

namespace App\Enums;

interface RequestStep {
    const LIST_REQUESTS = 'lr';
    const LIST_REQUEST_ITEMS = 'lri';
}
