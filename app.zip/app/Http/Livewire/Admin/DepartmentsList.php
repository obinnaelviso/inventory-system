<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class DepartmentsList extends Component
{
    public function render()
    {
        return view('livewire.admin.departments-list');
    }
}
