<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class StocksList extends Component
{
    public function render()
    {
        return view('livewire.admin.stocks-list');
    }
}
