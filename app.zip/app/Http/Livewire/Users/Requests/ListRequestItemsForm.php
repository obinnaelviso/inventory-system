<?php

namespace App\Http\Livewire\Users\Requests;

use Livewire\Component;

class ListRequestItemsForm extends Component
{
    public function render()
    {
        return view('livewire.users.requests.list-request-items-form');
    }
}
