<?php

namespace App\Enums;

interface RoleEnum {
    const ADMIN = 'admin';
    const USER = 'user';
}
