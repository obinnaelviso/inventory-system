<?php

namespace App\Enums;

interface StockStep {
    const LIST_STOCKS = 'ls';
    const LIST_STOCK_ITEMS = 'lsi';
}
