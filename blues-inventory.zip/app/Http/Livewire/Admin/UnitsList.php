<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class UnitsList extends Component
{
    public function render()
    {
        return view('livewire.admin.units-list');
    }
}
