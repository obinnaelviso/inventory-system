<?php

namespace App\Http\Livewire\User;

use Livewire\Component;

class StockList extends Component
{
    public function render()
    {
        return view('livewire.user.stock-list');
    }
}
