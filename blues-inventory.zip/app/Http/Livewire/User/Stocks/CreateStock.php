<?php

namespace App\Http\Livewire\User;

use Livewire\Component;

class CreateStock extends Component
{
    public function render()
    {
        return view('livewire.user.create-stock');
    }
}
