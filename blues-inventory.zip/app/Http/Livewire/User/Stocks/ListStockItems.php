<?php

namespace App\Http\Livewire\User\Stocks;

use Livewire\Component;

class ListStockItems extends Component
{
    public function render()
    {
        return view('livewire.user.stocks.list-stock-items');
    }
}
