<?php

namespace App\Http\Livewire\User\Stocks;

use Livewire\Component;

class ListStocks extends Component
{
    public function render()
    {
        return view('livewire.user.stocks.list-stocks');
    }
}
