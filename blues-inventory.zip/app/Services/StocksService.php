<?php

namespace App\Services;

class StocksService {

    public function __construct() {

    }
}
