<li>
    <a href="{{ route('dashboard') }}">
        <div class="parent-icon"><i class='bx bx-home-circle'></i>
        </div>
        <div class="menu-title">Dashboard</div>
    </a>
</li>
<li>
    <a href="{{ route('user.requests.index') }}">
        <div class="parent-icon"><i class='bx bx-message-error'></i>
        </div>
        <div class="menu-title">Requests</div>
    </a>
</li>
<li>
    <a href="{{ route('user.stocks.index') }}">
        <div class="parent-icon"><i class='bx bx-coin-stack'></i>
        </div>
        <div class="menu-title">New Stocks</div>
    </a>
</li>
<li>
    <a href="{{ route('user.products.index') }}">
        <div class="parent-icon"><i class='bx bx-extension'></i>
        </div>
        <div class="menu-title">Products</div>
    </a>
</li>
