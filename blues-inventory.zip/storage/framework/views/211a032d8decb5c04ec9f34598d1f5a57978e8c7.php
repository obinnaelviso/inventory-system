<div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table id="stocksTable" data-get-url="<?php echo e(route('admin.stocks.data')); ?>" class="table">
                        <thead>
                            <tr>
                                <th width="12%">Purchase #</th>
                                <th width="20%">User</th>
                                <th width="20%">Purchaser Name</th>
                                <th width="15%">Receipt No.</th>
                                <th width="13%">Receipt Upload</th>
                                <th width="20%">Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\blues-inventory\resources\views/livewire/admin/stocks-list.blade.php ENDPATH**/ ?>