<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $this->requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-12 col-sm-6 col-md-4 col-lg-3">
            <div class="card radius-10 zoom cursor-pointer">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div onclick="gotoRequest(<?php echo e($request->id); ?>)">
                            <p class="mb-0 text-secondary">Name</p>
                            <h4 class="my-1"><?php echo e($request->name); ?></h4>
                            <div class="row">
                                <div class="col-12">
                                    <p class="mb-0 font-13 text-muted"><strong>Dept:</strong> <?php echo e($request->dept); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="text-<?php echo e($request->status->colour[0]); ?> ms-auto">
                            <?php if($request->status_id == status_processing_id()): ?>
                                <i class="bx bx-check-circle font-35"></i>
                            <?php else: ?>
                                <i class="bx bx-message-error font-35"></i>
                            <?php endif; ?>
                            <?php if($request->status_id == status_pending_id()): ?>
                                <div class="row">
                                    <div class="col-12 text-end mb-0 font-18">
                                        <a href="javascript:void(0);" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit Request" class="text-info" onclick="editRequest(<?php echo e($request->id); ?>)">
                                            <i class="bx bx-edit"></i>
                                        </a>
                                        <a href="javascript:void(0);" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete Request" class="text-danger" onclick="openDeleteRequestModal(<?php echo e($request->id); ?>)">
                                            <i class="bx bx-trash"></i>
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="card radius-2">
                <div class="card-body text-center py-5">
                    <p class="my-5">No requests record found. <br>Click the button below to <a href="javascript:void(0);" class="requestCreateBtn">create a new one.</a></p>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="modal fade" id="deleteRequestModal" tabindex="-1" aria-labelledby="deleteUserModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="deleteRequestModalTitle">Delete Request</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this request?<br>
                    <div class="text-danger"><strong>Note:</strong> Deleting request will automatically remove all items relating to it.</div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Not yet</button>
                    <button type="button" class="btn btn-danger btn-sm" id="modalDeleteBtn" onclick="deleteRequest();">Delete</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\blues-inventory\resources\views/livewire/user/requests/list-requests.blade.php ENDPATH**/ ?>