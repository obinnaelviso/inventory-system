<div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table id="requestsTable" data-get-url="<?php echo e(route('admin.requests.data')); ?>" class="table">
                        <thead>
                            <tr>
                                <th width="10%">SL#</th>
                                <th width="15%">User</th>
                                <th width="15%">Name</th>
                                <th width="15%">Dept</th>
                                <th width="10%">Date</th>
                                <th width="10%">Status</th>
                                <th width="25%">Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\blues-inventory\resources\views/livewire/admin/requests-list.blade.php ENDPATH**/ ?>