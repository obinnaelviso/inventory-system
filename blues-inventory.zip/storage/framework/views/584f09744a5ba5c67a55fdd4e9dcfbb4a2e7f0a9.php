<?php $__env->startSection('title', 'Request Items'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
        <div class="breadcrumb-title pe-3"><?php echo $__env->yieldContent('title'); ?></div>
        <div class="ms-auto">
            <button class="btn btn-primary requestItemCreateBtn">
                <i class="bx bx-coin-stack"></i>Add New Item
            </button>
        </div>
    </div>
    <!--end breadcrumb-->

    <div class="page-class">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.request-items', ['request' => $request])->html();
} elseif ($_instance->childHasBeenRendered('mTItGy4')) {
    $componentId = $_instance->getRenderedChildComponentId('mTItGy4');
    $componentTag = $_instance->getRenderedChildComponentTagName('mTItGy4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mTItGy4');
} else {
    $response = \Livewire\Livewire::mount('admin.request-items', ['request' => $request]);
    $html = $response->html();
    $_instance->logRenderedChild('mTItGy4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugins'); ?>
<link href="<?php echo e(asset('assets/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
<?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script src="<?php echo e(asset('assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatable/js/dataTables.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin/requests-items.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('modals'); ?>
    <!-- New/Update Modal -->
    <div class="modal fade" id="requestItemFormModal" tabindex="-1" aria-labelledby="requestItemFormModalLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="requestItemFormModalTitle">Modal title</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.request-items-form', ['request' => $request])->html();
} elseif ($_instance->childHasBeenRendered('bXz0M1W')) {
    $componentId = $_instance->getRenderedChildComponentId('bXz0M1W');
    $componentTag = $_instance->getRenderedChildComponentTagName('bXz0M1W');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bXz0M1W');
} else {
    $response = \Livewire\Livewire::mount('admin.request-items-form', ['request' => $request]);
    $html = $response->html();
    $_instance->logRenderedChild('bXz0M1W', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
        </div>
    </div>
    <div class="modal fade" id="requestItemDeleteModal" tabindex="-1" aria-labelledby="requestItemDeleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="requestItemDeleteModalTitle">Delete Item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this Item?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Not yet</button>
                    <button type="button" class="btn btn-danger btn-sm" id="modalDeleteBtn" onclick="deleteItem();">Delete</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="markAsCompletedModal" tabindex="-1" aria-labelledby="markAsCompletedModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="markAsCompletedModalTitle">Mark Item as Complete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to mark this item as complete?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger btn-sm" data-bs-dismiss="modal">Not yet</button>
                    <button type="button" class="btn btn-success btn-sm" id="modalMarkAsCompleteBtn" onclick="markAsCompleted();">Yes</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="addToProductsModal" tabindex="-1" aria-labelledby="addToProductsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="addToProductsModalTitle">Add To Products</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to add this item to products?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger btn-sm" data-bs-dismiss="modal">Not yet</button>
                    <button type="button" class="btn btn-success btn-sm" id="modalMarkAsCompleteBtn" onclick="addItemToProducts();">Yes</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blues-inventory\resources\views/admin/requests/items.blade.php ENDPATH**/ ?>