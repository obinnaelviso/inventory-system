<div>
    <?php if($step == RequestStep::LIST_REQUESTS): ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.requests.list-requests', [])->html();
} elseif ($_instance->childHasBeenRendered('l3371438633-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3371438633-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3371438633-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3371438633-0');
} else {
    $response = \Livewire\Livewire::mount('user.requests.list-requests', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3371438633-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php elseif($step == RequestStep::LIST_REQUEST_ITEMS && $r): ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.requests.list-request-items', ['request' => $r])->html();
} elseif ($_instance->childHasBeenRendered('l3371438633-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3371438633-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3371438633-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3371438633-1');
} else {
    $response = \Livewire\Livewire::mount('user.requests.list-request-items', ['request' => $r]);
    $html = $response->html();
    $_instance->logRenderedChild('l3371438633-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\blues-inventory\resources\views/livewire/user/requests/index.blade.php ENDPATH**/ ?>