<div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table id="productsTable" data-get-url="<?php echo e(route('products.index')); ?>" class="table">
                        <thead>
                            <tr>
                                <th width="5%">SL#</th>
                                <th width="15%">Item</th>
                                <th width="25%">Description</th>
                                <th width="25%">Category</th>
                                <th width="5%">Qty</th>
                                <th width="10%">Unit</th>
                                <th width="15%">Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\blues-inventory\resources\views/livewire/list-products.blade.php ENDPATH**/ ?>