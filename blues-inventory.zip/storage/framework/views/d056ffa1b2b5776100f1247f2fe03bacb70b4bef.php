<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
        <h3><?php echo $__env->yieldContent('title'); ?></h3>
        
    </div>
    <!--end breadcrumb-->

    <div class="page-class">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blues-inventory\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>