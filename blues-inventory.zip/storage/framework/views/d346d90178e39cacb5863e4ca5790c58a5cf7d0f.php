<li>
    <a href="<?php echo e(route('dashboard')); ?>">
        <div class="parent-icon"><i class='bx bx-home-circle'></i>
        </div>
        <div class="menu-title">Dashboard</div>
    </a>
</li>
<li>
    <a href="<?php echo e(route('user.requests.index')); ?>">
        <div class="parent-icon"><i class='bx bx-message-error'></i>
        </div>
        <div class="menu-title">Requests</div>
    </a>
</li>
<li>
    <a href="<?php echo e(route('user.stocks.index')); ?>">
        <div class="parent-icon"><i class='bx bx-coin-stack'></i>
        </div>
        <div class="menu-title">Stocks</div>
    </a>
</li>
<li>
    <a href="<?php echo e(route('user.products.index')); ?>">
        <div class="parent-icon"><i class='bx bx-extension'></i>
        </div>
        <div class="menu-title">Products</div>
    </a>
</li>
<?php /**PATH C:\xampp\htdocs\blues-inventory\resources\views/layouts/sidebar/user.blade.php ENDPATH**/ ?>