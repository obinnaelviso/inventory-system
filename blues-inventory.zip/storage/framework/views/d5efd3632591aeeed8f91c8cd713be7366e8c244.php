<?php $__env->startSection('title', 'New Stocks'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
        <div class="breadcrumb-title pe-3"><?php echo $__env->yieldContent('title'); ?></div>
        <div class="ms-auto">
            <button class="btn btn-primary stockCreateBtn">
                <i class="bx bx-coin-stack"></i>Add New Stock
            </button>
        </div>
    </div>
    <!--end breadcrumb-->

    <div class="page-class">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.stocks-list', [])->html();
} elseif ($_instance->childHasBeenRendered('IgshFog')) {
    $componentId = $_instance->getRenderedChildComponentId('IgshFog');
    $componentTag = $_instance->getRenderedChildComponentTagName('IgshFog');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IgshFog');
} else {
    $response = \Livewire\Livewire::mount('admin.stocks-list', []);
    $html = $response->html();
    $_instance->logRenderedChild('IgshFog', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugins'); ?>
<link href="<?php echo e(asset('assets/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
<?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script src="<?php echo e(asset('assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatable/js/dataTables.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin/stocks.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('modals'); ?>
    <!-- New/Update Modal -->
    <div class="modal fade" id="stockFormModal" tabindex="-1" aria-labelledby="stockFormModalLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="stockFormModalTitle">Modal title</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('stocks-form', [])->html();
} elseif ($_instance->childHasBeenRendered('fb0gKnu')) {
    $componentId = $_instance->getRenderedChildComponentId('fb0gKnu');
    $componentTag = $_instance->getRenderedChildComponentTagName('fb0gKnu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fb0gKnu');
} else {
    $response = \Livewire\Livewire::mount('stocks-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('fb0gKnu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
        </div>
    </div>
    <div class="modal fade" id="stockDeleteModal" tabindex="-1" aria-labelledby="stockDeleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="stockDeleteModalTitle">Delete Stock</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this stock?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Not yet</button>
                    <button type="button" class="btn btn-danger btn-sm" id="modalDeleteBtn" onclick="confirmStockDelete();">Delete</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blues-inventory\resources\views/admin/stocks/index.blade.php ENDPATH**/ ?>