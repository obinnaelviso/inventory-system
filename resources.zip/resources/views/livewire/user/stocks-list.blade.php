<div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table id="stocksTable" data-get-url="{{ route('user.stocks.data') }}" class="table">
                        <thead>
                            <tr>
                                <th width="15%">Purchase #</th>
                                <th width="20%">Purchaser Name</th>
                                <th width="20%">Receipt No.</th>
                                <th width="20%">Receipt Upload</th>
                                <th width="25%">Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
